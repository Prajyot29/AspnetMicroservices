﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using BookApi.Models;
using BookApi.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IBookRepository bookRepository;
        private readonly IWebHostEnvironment webHostEnvironment;

        public BookController(IBookRepository bookRepository, IWebHostEnvironment webHostEnvironment)
        {
            this.bookRepository = bookRepository;
            this.webHostEnvironment = webHostEnvironment;
        }

        [HttpGet]
        public async Task<ActionResult<book>> GellAll()
        {
            var books = await bookRepository.GetAllBook();
            return Ok(books);
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<ActionResult<book>> GetById(int id)
        {
            var bookItem = await bookRepository.GetBookById(id);
            return Ok(bookItem);
        }

        [HttpPost]
        public async Task<ActionResult> AddBook(book entity)
        {
            await bookRepository.AddBook(entity);
            return Ok(entity);
        }

        [HttpPost]
        [Route("AddBookBySP")]
        public async Task<ActionResult> AddBookBySP(book entity)
        {
            await bookRepository.AddBookByStoredProcedure(entity);
            return Ok(entity);
        }


        [HttpPut("{id}")]
        public async Task<ActionResult<book>> Update(book entity, int id)
        {
            await bookRepository.UpdateBook(entity, id);
            return Ok(entity);
        }


        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await bookRepository.RemoveBook(id);
            return Ok();
        }



        [HttpPost]
        [Route("uploader")]
        public ActionResult UploadFile(IFormFile MyUploader)
        {
            if (MyUploader != null)
            {
                string uploadsFolder = Path.Combine(webHostEnvironment.WebRootPath, "mediaUpload");
                string filePath = Path.Combine(uploadsFolder, MyUploader.FileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    MyUploader.CopyTo(fileStream);
                }
                return new ObjectResult(new { status = "success" });
            }
            return new ObjectResult(new { status = "fail" });
        }

    }
}
