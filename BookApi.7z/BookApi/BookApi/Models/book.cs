﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookApi.Models
{
    public class book
    {
        public int book_id { get; set; }
        public string book_name { get; set; }
        public string book_desc { get; set; }
    }
}
