﻿using BookApi.Models;
using BookApi.Services.Queries;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace BookApi.Services
{
    public class BookRepository : BaseRepository, IBookRepository
    {
        private readonly ICommandText _commandText;

        public BookRepository(IConfiguration configuration, ICommandText commandText) : base(configuration)
        {
            _commandText = commandText;

        }

        public async Task AddBook(book entity)
        {
            await WithConnection(async conn =>
            {
                await conn.ExecuteAsync(_commandText.AddBook,
                    new { book_name = entity.book_name, book_desc = entity.book_desc, book_id = entity.book_id });
            });
        }

        

        public async Task<IEnumerable<book>> GetAllBook()
        {

            return await WithConnection(async conn =>
            {
                var query = await conn.QueryAsync<book>(_commandText.GetBookList);
                return query;
            });
        }

        public async ValueTask<book> GetBookById(int id)
        {
            return await WithConnection(async conn =>
            {
                var query = await conn.QueryFirstOrDefaultAsync<book>(_commandText.GetBookById, new { book_id = id });
                return query;
            });
        }

        public async Task RemoveBook(int id)
        {
            await WithConnection(async conn =>
            {
                await conn.ExecuteAsync(_commandText.DeleteBook, new { book_id = id });
            });
        }

        public async Task UpdateBook(book entity, int id)
        {
            await WithConnection(async conn =>
            {
                await conn.ExecuteAsync(_commandText.UpdateBook,
                    new { book_name = entity.book_name, book_desc = entity.book_desc, book_id = id });
            });
        }
        public class Parameters : DynamicParameters
        {
            public new void Add(string name, object value = null, DbType? dbType = null, ParameterDirection? direction = null, int? size = null)
            {
                if (dbType == null && value is string)
                {
                    if (size == null)
                    {
                        dbType = DbType.AnsiString;
                    }
                    else
                    {
                        dbType = DbType.AnsiStringFixedLength;
                    }
                }
                base.Add(name, value, dbType, direction, size);
            }
        }


        public async Task AddBookByStoredProcedure(book entity)
        {
            await WithConnection(async conn =>
            {
              //  var p = new Parameters();
                var p = new DynamicParameters();
                p.Add("@book_id", entity.book_id);
                p.Add("@book_name", entity.book_name);
                p.Add("@book_desc", entity.book_desc);
                                
                string myProc = "CALL \"" + _commandText.AddBookByStoredProcedure + "\"(@book_id,@book_name,@book_desc)";
               
                await conn.ExecuteAsync(myProc, p);
            });
        }
    }
}
