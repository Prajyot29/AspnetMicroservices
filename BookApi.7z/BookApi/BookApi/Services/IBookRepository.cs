﻿using BookApi.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookApi.Services
{

    public interface IBookRepository
    {
        ValueTask<book> GetBookById(int id);
        Task AddBook(book entity);
        Task UpdateBook(book entity, int id);
        Task RemoveBook(int id);
        Task<IEnumerable<book>> GetAllBook();

        Task AddBookByStoredProcedure(book entity);
    }
}
