﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookApi.Services.Queries
{
    public class CommandText : ICommandText
    {
        public string GetBookList => "Select * from Book";

        public string GetBookById => "Select * from Book where book_id= @book_id";

        public string AddBook => "INSERT INTO book (book_id,book_name,book_desc) values (@book_id,@book_name,@book_desc)";

        public string UpdateBook => "Update book set book_name = @book_name, book_desc = @book_desc where book_id =@book_id";

        public string DeleteBook => "Delete from book where book_id= @book_id";

        public string AddBookByStoredProcedure => "CALL usp_addbook (asasas)";
    }
}
