﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookApi.Services.Queries
{
    public interface ICommandText
    {
        string GetBookList { get; }
        string GetBookById { get; }
        string AddBook { get; }
        string UpdateBook { get; }
        string DeleteBook { get; }
        string AddBookByStoredProcedure { get; }
    }
}
