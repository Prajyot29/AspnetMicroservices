﻿namespace PaymentService.Api.Queries.Dtos
{
    public class PolicyAccountDto
    {
        public string PolicyAccountNumber { get; set; }
        public string PolicyNumber { get; set; }
    }
}
