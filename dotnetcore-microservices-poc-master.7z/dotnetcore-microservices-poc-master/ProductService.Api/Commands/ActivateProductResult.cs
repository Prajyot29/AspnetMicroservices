using System;

namespace ProductService.Api.Commands
{
    public class ActivateProductResult
    {
        public Guid ProductId { get; set; }
    }
}