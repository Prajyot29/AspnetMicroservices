using System;

namespace ProductService.Api.Commands
{
    public class DiscontinueProductResult 
    {
        public Guid ProductId { get; set; }
    }
}