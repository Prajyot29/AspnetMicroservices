namespace AuthService.Domain
{
    public class AuthRequest
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}