using PolicyService.Api.Queries.Dto;

namespace PolicyService.Api.Queries
{
    public class GetPolicyDetailsQueryResult
    {
        public PolicyDetailsDto Policy { get; set; }    
    }
}