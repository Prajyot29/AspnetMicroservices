namespace PaymentService.Domain
{
    public enum PolicyAccountStatus
    {
        Active,
        Terminated
    }
}