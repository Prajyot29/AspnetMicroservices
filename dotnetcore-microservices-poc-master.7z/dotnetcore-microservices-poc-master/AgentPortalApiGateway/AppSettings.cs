namespace AgentPortalApiGateway
{
    public class AppSettings
    {
        public string[] AllowedChatOrigins { get; set; }
    }
}