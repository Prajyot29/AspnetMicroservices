docker-compose -f infra.yml up -d
