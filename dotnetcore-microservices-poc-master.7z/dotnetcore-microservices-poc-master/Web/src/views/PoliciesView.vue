<template>
    <div>
        <PolicyList />
    </div>
</template>

<script>
    import PolicyList from "../components/PolicyList";

    export default {
        name: 'policies',
        components: {
            PolicyList
        }
    }
</script>