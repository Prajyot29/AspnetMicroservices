<template>
    <div>
        <Account />
    </div>
</template>

<script>
    import Account from '@/components/Account.vue'

    export default {
        name: 'account',
        components: {
            Account
        }
    }
</script>
